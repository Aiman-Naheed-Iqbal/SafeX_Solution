# SafeX AI Automation Demo — Social Caption Workflow

## Business problem
Small local businesses often need frequent social posts but spend time manually
turning an offer into a platform-appropriate caption. The Week 1 project already
generated captions from topics; this version turns it into a reusable automation
workflow that takes business + offer + audience + platform + tone + CTA and
produces a ready-to-post caption and hashtags.

## What improved from Week 1
- Structured input validation
- Business-specific context instead of only generic cyber topics
- Platform-aware formatting for Instagram, Facebook, LinkedIn and Twitter/X
- Tone selection
- Custom CTA
- Automatic hashtag selection
- Deterministic output for reliable demos
- Five realistic test cases
- CSV export of all generated outputs

## Run locally
```bash
python automation_demo.py
```

No paid API key is required.

## Demo acceptance test
The script must print:
`✓ 5/5 sample inputs generated successfully.`

and create:
`demo_outputs.csv`

## Suggested 2–3 minute recording
1. 0:00–0:20 — Show the original Week 1 generator and explain the limitation:
   generic templates required manual editing.
2. 0:20–0:45 — Open `automation_demo.py` and show the structured request fields.
3. 0:45–2:15 — Run the script and scroll through all five generated outputs.
4. 2:15–2:40 — Open `demo_outputs.csv` and show the structured results.
5. 2:40–3:00 — Explain the business value: faster posting, consistent brand voice,
   and less repetitive work.

## Important
The lead research sheet included with this package separates **publicly verified
facts** from **unverified pain/interest**. Do not report an inferred pain point as
a customer-stated pain point until the business replies.
