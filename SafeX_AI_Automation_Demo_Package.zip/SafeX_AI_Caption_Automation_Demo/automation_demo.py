"""
SafeX AI Social Caption Automation Demo
Week 2 extension of the original SocialCaptionGenerator.

Run:
    python automation_demo.py

The demo uses deterministic rule-based "AI-style" generation so it is free,
repeatable, and reliable for demonstrations. It accepts business details,
creates a platform/tone-aware caption, CTA, and hashtags, and can process
multiple inputs into a CSV.
"""

from dataclasses import dataclass
import csv
import re
from typing import List


@dataclass
class CaptionRequest:
    business: str
    offer: str
    audience: str
    platform: str = "Instagram"
    tone: str = "Friendly"
    cta: str = "DM us to learn more."


PLATFORM_RULES = {
    "Instagram": {"length": 500, "hashtags": 6, "hook": "✨"},
    "Facebook": {"length": 700, "hashtags": 5, "hook": "📣"},
    "LinkedIn": {"length": 650, "hashtags": 4, "hook": "💡"},
    "Twitter/X": {"length": 260, "hashtags": 3, "hook": "⚡"},
}

TONE_WORDS = {
    "Professional": "simple, practical, and trustworthy",
    "Friendly": "helpful, warm, and approachable",
    "Energetic": "clear, upbeat, and action-focused",
    "Educational": "useful, clear, and easy to understand",
}

GENERIC_HASHTAGS = [
    "#SmallBusiness", "#LocalBusiness", "#BusinessGrowth",
    "#SocialMediaMarketing", "#SafeX"
]


def clean(value: str, field: str) -> str:
    value = (value or "").strip()
    if not value:
        raise ValueError(f"{field} is required.")
    return re.sub(r"\s+", " ", value)


def generate_caption(req: CaptionRequest) -> dict:
    business = clean(req.business, "Business")
    offer = clean(req.offer, "Offer")
    audience = clean(req.audience, "Audience")
    platform = clean(req.platform, "Platform")
    tone = clean(req.tone, "Tone")
    cta = clean(req.cta, "CTA")

    rules = PLATFORM_RULES.get(platform, PLATFORM_RULES["Instagram"])
    tone_desc = TONE_WORDS.get(tone, TONE_WORDS["Friendly"])

    hook = {
        "Instagram": f"{rules['hook']} {offer} — made for {audience}.",
        "Facebook": f"{rules['hook']} Looking for {offer.lower()}?",
        "LinkedIn": f"{rules['hook']} A practical update from {business}.",
        "Twitter/X": f"{rules['hook']} {offer} for {audience}.",
    }.get(platform, f"{rules['hook']} {offer}.")

    body = (
        f"{hook}\n\n"
        f"At {business}, we focus on making the experience {tone_desc}. "
        f"If you're {audience.lower()}, this is designed to help you "
        f"get more value with less hassle.\n\n"
        f"{cta}"
    )

    # Platform-specific compression for Twitter/X.
    if platform == "Twitter/X" and len(body) > 230:
        body = f"{hook} {cta}"

    tag_count = rules["hashtags"]
    topic_words = re.findall(r"[A-Za-z0-9]+", offer.title())
    topic_tags = ["#" + w for w in topic_words if len(w) > 3][:3]
    hashtags = []
    for tag in topic_tags + GENERIC_HASHTAGS:
        if tag.lower() not in [x.lower() for x in hashtags]:
            hashtags.append(tag)
        if len(hashtags) >= tag_count:
            break

    caption = body + "\n\n" + " ".join(hashtags)
    if len(caption) > rules["length"]:
        caption = caption[:rules["length"]].rsplit(" ", 1)[0] + "…"

    return {
        "business": business,
        "platform": platform,
        "tone": tone,
        "caption": caption,
        "hashtags": " ".join(hashtags),
    }


SAMPLES = [
    CaptionRequest(
        "Glow Beauty Studio", "Bridal makeup packages", "brides preparing for their wedding",
        "Instagram", "Friendly", "Book a consultation by DM."
    ),
    CaptionRequest(
        "Urban Bites Cafe", "Weekend brunch menu", "families and young professionals",
        "Facebook", "Energetic", "Message us for this weekend's menu."
    ),
    CaptionRequest(
        "Prime Fitness", "Beginner strength program", "people starting their fitness journey",
        "Instagram", "Educational", "DM us for a free trial."
    ),
    CaptionRequest(
        "Manahil Estate", "Bahria Town property consultation", "buyers comparing investment options",
        "LinkedIn", "Professional", "Book a consultation to discuss your options."
    ),
    CaptionRequest(
        "LocalTech Solutions", "small-business cybersecurity audit", "local businesses protecting customer data",
        "Twitter/X", "Professional", "Reply or DM to arrange a quick audit."
    ),
]


def run_demo() -> None:
    print("=" * 72)
    print("SafeX AI Social Caption Automation — 5-input reliability demo")
    print("=" * 72)

    outputs = []
    for i, sample in enumerate(SAMPLES, 1):
        result = generate_caption(sample)
        outputs.append(result)
        print(f"\n--- SAMPLE {i}: {result['business']} / {result['platform']} ---")
        print(result["caption"])

    with open("demo_outputs.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=outputs[0].keys())
        writer.writeheader()
        writer.writerows(outputs)

    print("\n✓ 5/5 sample inputs generated successfully.")
    print("✓ Output saved to demo_outputs.csv")


if __name__ == "__main__":
    run_demo()
