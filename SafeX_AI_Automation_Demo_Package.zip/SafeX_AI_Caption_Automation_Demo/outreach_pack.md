# Outreach Pack

## Message 1 — first contact
Hi [Name], I’m testing a small AI automation for local businesses that turns a
business offer + audience + platform into a ready-to-post social caption in a few
seconds. I made a short demo using realistic small-business examples.

I’m not trying to sell you anything yet — I’m validating whether this actually
solves a real problem. How do you currently create your social captions, and what
part of the process takes the most time?

If useful, I can send the 2–3 minute demo.

## Message 2 — follow-up
Hi [Name], just following up on my earlier note. I’m researching how local
businesses handle recurring social-media content. If you’re open to it, I’d love
a one-minute answer: do you write captions yourself, have a staff member do them,
or use an agency/tool — and what’s the biggest frustration with that process?

## Qualification questions
1. Who currently writes your social captions?
2. How many posts do you prepare in a typical week?
3. How much time does caption writing take?
4. Do you create different versions for Instagram/Facebook/LinkedIn?
5. What is the biggest pain point: time, consistency, ideas, approvals, or results?
6. Would a tool that generated a first draft automatically be useful?
7. Interest from 1–5?
