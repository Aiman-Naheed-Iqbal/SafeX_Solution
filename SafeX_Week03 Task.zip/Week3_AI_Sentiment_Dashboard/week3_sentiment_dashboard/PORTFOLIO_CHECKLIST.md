# Submission Checklist

[x] Project title and problem
[x] Dataset
[x] Sentiment approach
[x] Theme categories
[x] Dashboard app
[x] Three core charts
[x] Filters
[x] Most-negative callout
[x] Export report
[x] 15-item validation notes
[x] Failure cases
[x] Weaknesses and fixes
[x] README
[x] Screenshot-ready charts
[ ] GitHub repo URL
[ ] Live deployment URL
[ ] Screen-recorded final video

## Video order
Name → internship category → project title → problem → approach → tools → dashboard walkthrough → validation → challenges/fixes → final result → learning → future improvements.
