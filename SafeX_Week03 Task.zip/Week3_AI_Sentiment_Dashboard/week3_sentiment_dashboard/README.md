# Week 3 — AI Sentiment Analysis Dashboard for Customer Feedback

## Problem
Businesses collect customer feedback but often lack a systematic way to detect sentiment trends and recurring issues.

## Solution
A Python + Streamlit dashboard analyzes feedback using VADER sentiment scoring and transparent keyword-based theme tagging.

## Features
- CSV upload
- Positive / Neutral / Negative sentiment
- Compound sentiment score
- Sentiment-over-time chart
- Common theme chart
- Sentiment/theme filters
- Most-negative urgent follow-up queue
- Exportable summary report
- Feedback explorer table

## Dataset
40 realistic sample comments are included in `data/customer_feedback.csv`.

## Tools
Python, pandas, VADER Sentiment, Streamlit, matplotlib, Jupyter.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Validation
15 comments were reviewed manually. The prototype achieved **15/15 (100%) on this small sample**. This is not production accuracy because the dataset is synthetic and the sample is small. See `docs/validation_notes.md`.

## Weaknesses fixed
1. Expanded theme coverage.
2. Added urgent negative-comment callouts.
3. Added filters.
4. Added export functionality.

## Future improvements
Use embeddings/clustering for themes, a transformer model for nuanced sentiment, multilingual support, confidence scoring, a database, authentication, and cloud deployment.

## Portfolio summary
**AI Customer Feedback Sentiment Dashboard** — Built a Python/Streamlit prototype that converts raw customer comments into sentiment scores, trend charts, recurring themes, and an urgent follow-up queue, with manual validation and documented failure cases.
