import io
from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="AI Customer Feedback Sentiment Dashboard",
    page_icon="📊",
    layout="wide"
)


# ============================================================
# PROJECT PATH
# ============================================================

# This automatically finds the folder containing app.py.
# Therefore, the CSV works regardless of where Streamlit is started.

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "customer_feedback.csv"


# ============================================================
# THEME DEFINITIONS
# ============================================================

THEMES = {
    "Performance": [
        "slow",
        "slower",
        "freezes",
        "freeze",
        "crashed",
        "crash",
        "battery",
        "painfully"
    ],

    "Support": [
        "support",
        "replied",
        "reply",
        "help center",
        "customer service",
        "answer",
        "contacting"
    ],

    "Pricing": [
        "price",
        "pricing",
        "expensive",
        "subscription",
        "paid",
        "cost"
    ],

    "UX / Navigation": [
        "design",
        "interface",
        "navigation",
        "menus",
        "menu",
        "onboarding",
        "settings",
        "filters",
        "filter"
    ],

    "Payments / Refunds": [
        "payment",
        "charged",
        "refund",
        "checkout"
    ],

    "Delivery / Product": [
        "delivery",
        "delivered",
        "arrived",
        "damaged",
        "packaging",
        "product quality",
        "product"
    ],

    "Account / Login": [
        "logged out",
        "password",
        "account",
        "access",
        "login",
        "log in"
    ],

    "Notifications": [
        "notifications",
        "notification"
    ],

    "Search": [
        "search"
    ],

    "Files / Uploads": [
        "upload",
        "uploads",
        "uploaded",
        "pdf",
        "file",
        "files"
    ],

    "Reporting / Analytics": [
        "reports",
        "report",
        "analytics",
        "dashboard"
    ],

    "Reliability / Bugs": [
        "bugs",
        "bug",
        "crashed",
        "crash",
        "freezes",
        "freeze",
        "issue",
        "issues"
    ]
}


# ============================================================
# LOAD DATA
# ============================================================

@st.cache_data
def load_data(uploaded_file=None):

    if uploaded_file is not None:

        data = pd.read_csv(uploaded_file)

    else:

        if not DATA_FILE.exists():

            st.error(
                "CSV file not found.\n\n"
                f"Expected location:\n{DATA_FILE}"
            )

            st.stop()

        data = pd.read_csv(DATA_FILE)

    # Check required columns

    required_columns = ["date", "comment"]

    missing_columns = [
        column
        for column in required_columns
        if column not in data.columns
    ]

    if missing_columns:

        st.error(
            "Your CSV is missing these required columns: "
            + ", ".join(missing_columns)
        )

        st.stop()

    data["date"] = pd.to_datetime(
        data["date"],
        errors="coerce"
    )

    data["comment"] = data["comment"].fillna("").astype(str)

    return data


# ============================================================
# SENTIMENT + THEME ANALYSIS
# ============================================================

@st.cache_data
def analyze_data(data):

    analyzer = SentimentIntensityAnalyzer()

    result = data.copy()

    # --------------------------------------------------------
    # VADER SENTIMENT SCORES
    # --------------------------------------------------------

    scores = result["comment"].apply(
        analyzer.polarity_scores
    )

    result["positive_score"] = scores.apply(
        lambda x: x["pos"]
    )

    result["negative_score"] = scores.apply(
        lambda x: x["neg"]
    )

    result["neutral_score"] = scores.apply(
        lambda x: x["neu"]
    )

    result["compound"] = scores.apply(
        lambda x: x["compound"]
    )

    # --------------------------------------------------------
    # SENTIMENT CLASSIFICATION
    # --------------------------------------------------------

    def classify_sentiment(score):

        if score >= 0.05:
            return "Positive"

        elif score <= -0.05:
            return "Negative"

        else:
            return "Neutral"

    result["sentiment"] = result["compound"].apply(
        classify_sentiment
    )

    # --------------------------------------------------------
    # THEME TAGGING
    # --------------------------------------------------------

    def identify_themes(text):

        text = str(text).lower()

        matched_themes = []

        for theme, keywords in THEMES.items():

            for keyword in keywords:

                if keyword in text:

                    matched_themes.append(theme)
                    break

        if not matched_themes:

            return "Other"

        return ", ".join(matched_themes)

    result["theme"] = result["comment"].apply(
        identify_themes
    )

    return result


# ============================================================
# HEADER
# ============================================================

st.title(
    "📊 AI Customer Feedback Sentiment Dashboard"
)

st.caption(
    "Week 3 AI Product Prototype — "
    "Sentiment Analysis, Theme Detection and Customer Insights"
)


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.title("⚙️ Dashboard Controls")

st.sidebar.markdown(
    "Upload your own customer-feedback CSV "
    "or use the included sample dataset."
)

uploaded_file = st.sidebar.file_uploader(
    "Upload CSV",
    type=["csv"]
)


# ============================================================
# LOAD + ANALYZE DATA
# ============================================================

data = load_data(uploaded_file)

data = analyze_data(data)


# ============================================================
# SIDEBAR FILTERS
# ============================================================

st.sidebar.header("🔎 Filters")


available_sentiments = sorted(
    data["sentiment"].unique()
)

selected_sentiments = st.sidebar.multiselect(
    "Sentiment",
    options=available_sentiments,
    default=available_sentiments
)


# Get all themes

available_themes = sorted(
    {
        theme.strip()
        for theme_list in data["theme"]
        for theme in theme_list.split(",")
    }
)


selected_themes = st.sidebar.multiselect(
    "Theme",
    options=available_themes,
    default=available_themes
)


# ============================================================
# APPLY FILTERS
# ============================================================

filtered_data = data[
    data["sentiment"].isin(selected_sentiments)
]

filtered_data = filtered_data[
    filtered_data["theme"].apply(
        lambda theme_string:
        any(
            theme in selected_themes
            for theme in theme_string.split(", ")
        )
    )
]


# ============================================================
# KPI METRICS
# ============================================================

st.subheader("📌 Feedback Overview")


total_feedback = len(filtered_data)

positive_count = int(
    (filtered_data["sentiment"] == "Positive").sum()
)

neutral_count = int(
    (filtered_data["sentiment"] == "Neutral").sum()
)

negative_count = int(
    (filtered_data["sentiment"] == "Negative").sum()
)


col1, col2, col3, col4 = st.columns(4)


with col1:

    st.metric(
        "Total Feedback",
        total_feedback
    )


with col2:

    st.metric(
        "Positive",
        positive_count
    )


with col3:

    st.metric(
        "Neutral",
        neutral_count
    )


with col4:

    st.metric(
        "Negative",
        negative_count
    )


# ============================================================
# SENTIMENT PERCENTAGES
# ============================================================

if total_feedback > 0:

    positive_percentage = (
        positive_count / total_feedback
    ) * 100

    negative_percentage = (
        negative_count / total_feedback
    ) * 100

    neutral_percentage = (
        neutral_count / total_feedback
    ) * 100

else:

    positive_percentage = 0
    negative_percentage = 0
    neutral_percentage = 0


st.markdown(
    f"""
    **Positive:** {positive_percentage:.1f}%  
    **Neutral:** {neutral_percentage:.1f}%  
    **Negative:** {negative_percentage:.1f}%
    """
)


# ============================================================
# OVERALL SENTIMENT CHART
# ============================================================

st.subheader("📊 Overall Sentiment Split")


sentiment_counts = (
    filtered_data["sentiment"]
    .value_counts()
    .reindex(
        ["Positive", "Neutral", "Negative"],
        fill_value=0
    )
)


fig1, ax1 = plt.subplots(
    figsize=(8, 4)
)

ax1.bar(
    sentiment_counts.index,
    sentiment_counts.values
)

ax1.set_title(
    "Customer Sentiment Distribution"
)

ax1.set_xlabel("Sentiment")

ax1.set_ylabel("Number of Comments")


for index, value in enumerate(
    sentiment_counts.values
):

    ax1.text(
        index,
        value + 0.2,
        str(value),
        ha="center"
    )


st.pyplot(
    fig1,
    use_container_width=True
)

plt.close(fig1)


# ============================================================
# SENTIMENT OVER TIME
# ============================================================

st.subheader("📈 Sentiment Over Time")


if len(filtered_data) > 0:

    trend = (
        filtered_data
        .groupby(["date", "sentiment"])
        .size()
        .unstack(fill_value=0)
    )

    fig2, ax2 = plt.subplots(
        figsize=(10, 4)
    )

    for sentiment in [
        "Positive",
        "Neutral",
        "Negative"
    ]:

        if sentiment in trend.columns:

            ax2.plot(
                trend.index,
                trend[sentiment],
                marker="o",
                label=sentiment
            )

    ax2.set_title(
        "Customer Sentiment Trend"
    )

    ax2.set_xlabel("Date")

    ax2.set_ylabel(
        "Number of Comments"
    )

    ax2.legend()

    plt.xticks(rotation=45)

    fig2.tight_layout()

    st.pyplot(
        fig2,
        use_container_width=True
    )

    plt.close(fig2)

else:

    st.info(
        "No data available for the selected filters."
    )


# ============================================================
# TOP THEMES
# ============================================================

st.subheader("🏷️ Top Complaint / Praise Themes")


if len(filtered_data) > 0:

    theme_counts = (
        filtered_data
        .assign(
            theme=filtered_data["theme"].str.split(", ")
        )
        .explode("theme")
        ["theme"]
        .value_counts()
        .head(10)
    )

    fig3, ax3 = plt.subplots(
        figsize=(9, 5)
    )

    theme_counts.sort_values().plot(
        kind="barh",
        ax=ax3
    )

    ax3.set_title(
        "Most Common Customer Feedback Themes"
    )

    ax3.set_xlabel(
        "Number of Mentions"
    )

    ax3.set_ylabel(
        "Theme"
    )

    fig3.tight_layout()

    st.pyplot(
        fig3,
        use_container_width=True
    )

    plt.close(fig3)

else:

    st.info(
        "No themes available for the selected filters."
    )


# ============================================================
# MOST NEGATIVE COMMENTS
# ============================================================

st.subheader(
    "🚨 Most Negative Comments — Urgent Follow-up"
)


negative_comments = (
    filtered_data
    .sort_values(
        by="compound",
        ascending=True
    )
    .head(5)
)


if len(negative_comments) > 0:

    for _, row in negative_comments.iterrows():

        st.error(
            f"Sentiment Score: {row['compound']:.2f}\n\n"
            f"Theme: {row['theme']}\n\n"
            f"{row['comment']}"
        )

else:

    st.success(
        "No negative comments found with the current filters."
    )


# ============================================================
# FEEDBACK EXPLORER
# ============================================================

st.subheader("🔍 Feedback Explorer")


display_columns = [
    "date",
    "sentiment",
    "compound",
    "theme",
    "comment"
]


st.dataframe(
    filtered_data[
        display_columns
    ].sort_values(
        "date",
        ascending=False
    ),
    use_container_width=True,
    hide_index=True
)


# ============================================================
# EXPORT SUMMARY REPORT
# ============================================================

st.subheader("📄 Export Summary Report")


report = io.StringIO()


report.write(
    "AI CUSTOMER FEEDBACK SENTIMENT DASHBOARD\n"
)

report.write(
    "=" * 55 + "\n\n"
)

report.write(
    f"Total Feedback: {total_feedback}\n"
)

report.write(
    f"Positive: {positive_count}\n"
)

report.write(
    f"Neutral: {neutral_count}\n"
)

report.write(
    f"Negative: {negative_count}\n\n"
)


report.write(
    "SENTIMENT PERCENTAGES\n"
)

report.write(
    "-" * 30 + "\n"
)

report.write(
    f"Positive: {positive_percentage:.1f}%\n"
)

report.write(
    f"Neutral: {neutral_percentage:.1f}%\n"
)

report.write(
    f"Negative: {negative_percentage:.1f}%\n\n"
)


# Themes

report.write(
    "TOP FEEDBACK THEMES\n"
)

report.write(
    "-" * 30 + "\n"
)


if len(filtered_data) > 0:

    theme_report = (
        filtered_data
        .assign(
            theme=filtered_data["theme"].str.split(", ")
        )
        .explode("theme")
        ["theme"]
        .value_counts()
        .head(10)
    )

    for theme, count in theme_report.items():

        report.write(
            f"- {theme}: {count} mentions\n"
        )


report.write(
    "\nMOST NEGATIVE COMMENTS\n"
)

report.write(
    "-" * 30 + "\n"
)


for _, row in negative_comments.iterrows():

    report.write(
        f"- Score: {row['compound']:.2f}\n"
    )

    report.write(
        f"  Theme: {row['theme']}\n"
    )

    report.write(
        f"  Comment: {row['comment']}\n\n"
    )


# ============================================================
# DOWNLOAD BUTTON
# ============================================================

st.download_button(
    label="⬇️ Download Summary Report",
    data=report.getvalue(),
    file_name="sentiment_summary_report.txt",
    mime="text/plain"
)


# ============================================================
# FOOTER
# ============================================================

st.markdown("---")

st.caption(
    "Week 3 AI Product Prototype | "
    "Python + pandas + VADER + Streamlit + matplotlib"
)