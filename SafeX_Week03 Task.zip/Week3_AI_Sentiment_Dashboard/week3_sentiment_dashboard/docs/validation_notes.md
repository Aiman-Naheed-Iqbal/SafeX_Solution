# Accuracy Validation Notes

15 comments were manually labeled and compared with the VADER result.

**Accuracy: 15 / 15 = 100% on this small validation sample.**

Do not claim 100% real-world accuracy: this is a synthetic dataset and a small validation sample.

## Failure cases investigated
- Mixed sentiment: praise plus complaint in one sentence
- Sarcasm / irony
- Negation such as “not bad”
- Very short comments
- Domain-specific language
- Multiple issues in one comment

## Improvements
- Expanded theme keywords
- Added urgent negative queue
- Added sentiment/theme filters
- Added CSV upload and report export
