# Social Media Caption Generator

## Project Overview

This project generates a 7-day social media content calendar using Python and reusable caption templates.

The generator reads topics from a text file, randomly selects a caption template, creates engaging social media captions, and exports the results to a CSV file.

---

## Features

- Generates 7 social media captions
- Uses reusable templates
- Creates a structured content calendar
- Exports data to CSV
- Easy to customize

---

## Technologies Used

- Python
- Pandas
- Random Module

---

## Project Structure

```
SocialCaptionGenerator/
│
├── captions.py
├── templates.py
├── topics.txt
├── content_calendar.csv
├── requirements.txt
└── README.md
```

---

## Installation

Install the required package:

```bash
pip install pandas
```

---

## Run the Project

```bash
python captions.py
```

---

## Output

The project creates:

```
content_calendar.csv
```

Example Columns:

- Day
- Platform
- Caption
- Hashtags

---

## SafeX Tone of Voice

- Professional
- Friendly
- Educational
- Action-Oriented

---

## Prompt Template Used

```
Cyber Tip

{topic}

Stay protected with SafeX.

#CyberSecurity #SafeX #StaySecure
```

---

## Manual Review Checklist

- Grammar checked
- Brand tone maintained
- Relevant hashtags
- Clear messaging
- Accurate cybersecurity information