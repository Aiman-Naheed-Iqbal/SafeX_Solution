import random
import pandas as pd
from templates import templates

# Read topics
with open("topics.txt", "r", encoding="utf-8") as file:
    topics = [line.strip() for line in file if line.strip()]

days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
]

platforms = [
    "LinkedIn",
    "Instagram",
    "Facebook",
    "Twitter/X",
    "LinkedIn",
    "Instagram",
    "Facebook"
]

captions = []
hashtags = []

for topic in topics:
    template = random.choice(templates)
    caption = template.format(topic=topic).strip()

    captions.append(caption)

    # Get the last non-empty line (hashtags)
    hashtag = caption.splitlines()[-1]
    hashtags.append(hashtag)

print("Topics:", len(topics))
print("Days:", len(days))
print("Platforms:", len(platforms))
print("Captions:", len(captions))
print("Hashtags:", len(hashtags))

df = pd.DataFrame({
    "Day": days,
    "Platform": platforms,
    "Caption": captions,
    "Hashtags": hashtags
})

print("\nGenerated Content Calendar\n")
print(df)

df.to_csv("content_calendar.csv", index=False)

print("\n✅ content_calendar.csv created successfully!")