# templates.py

templates = [
    """🔐 Cyber Tip of the Day

{topic}

Stay protected with SafeX and make cybersecurity part of your daily routine.

#CyberSecurity #SafeX #StaySecure #DigitalSafety
""",

    """💡 Did You Know?

{topic}

Small security habits can make a big difference. Stay safe with SafeX!

#CyberTips #OnlineSafety #SafeX #SecurityFirst
""",

    """🚀 SafeX Reminder

{topic}

Protect your digital world with simple and smart security practices.

#StaySafe #CyberAwareness #SafeX #CyberSecurity
""",

    """🛡️ Security Starts With You

{topic}

Every secure action today helps protect your future online.

#SecurityMatters #SafeX #StayProtected #CyberSafety
"""
]