
# Week 4 — AI-Assisted Website Quality Auditor (Tax Advisory)

## Objective
A small, portfolio-ready auditor that combines bounded rule-based website extraction with an LLM prompt for structured recommendations.

## Ethical / authorization scope
Use only on sites you own, have permission to audit, or are explicitly permitted to review. The crawler:
- stays on the same domain;
- caps the crawl at 12 HTML pages per site;
- waits 0.5 seconds between requests;
- times out after 12 seconds;
- never submits forms or logs in;
- records failures instead of crashing.

## What is automatically detected?
- pages found within the crawl limit
- navigation labels
- contact-form signals
- CTA text
- social links
- meta title and description
- image alt-text coverage
- basic request/load-time signal
- HTTP errors/timeouts

## What is AI-generated?
The LLM converts the JSON facts into:
- 0–100 score
- problems
- missing features
- prioritized recommendations
- confidence and human checks

The report must keep these two layers visibly separate.

## Run
```bash
python -m pip install -r requirements.txt
python auditor.py https://example.com https://example.org --out audit_facts.json
```

Then provide `audit_facts.json` to an LLM using `scoring_prompt.txt`.

For an API implementation, the same JSON can be passed to an OpenAI/Anthropic/Gemini structured-output call. Keep API keys in environment variables, never in Git.

## Suggested GitHub structure
- `auditor.py` — bounded crawler and fact extractor
- `scoring_prompt.txt` — LLM scoring prompt
- `requirements.txt` — dependencies
- `audit_facts.json` — example output (remove sensitive/private data)
- `submission_report.md` — portfolio report
- `README.md` — setup and limitations

## Limitations
- requests/BeautifulSoup does not execute JavaScript, so JS-rendered forms/navigation can be missed.
- Page count means pages found by this bounded crawl, not the site's true page count.
- Load time is a simple request timing, not Lighthouse or Core Web Vitals.
- A missing signal means "not detected", not necessarily "absent".
- Accessibility is only partially represented by image alt text.
- Social links may be hidden in scripts or loaded dynamically.
- AI scores are heuristic and should not be treated as objective business ratings.
- Human review is required for factual verification and prioritization.
