
"""
Week 4 - AI-Assisted Website Quality Auditor
Tax Advisory Sector

Ethical scope:
- Audit only public/authorized websites.
- Low request rate, same-domain crawling, bounded page count.
- No form submission, authentication bypass, or aggressive scanning.
"""

import argparse
import json
import time
from collections import deque
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

USER_AGENT = "Week4-Tax-Website-Auditor/1.0 (educational, low-rate)"
DEFAULT_TIMEOUT = 12
MAX_PAGES = 12
DELAY_SECONDS = 0.5

SOCIAL_HOSTS = (
    "facebook.com", "instagram.com", "linkedin.com",
    "x.com", "twitter.com", "youtube.com", "tiktok.com"
)

CTA_TERMS = (
    "contact", "get in touch", "book", "schedule", "consult",
    "request", "learn more", "talk to", "enquire", "inquire"
)

def same_domain(a, b):
    return urlparse(a).netloc.lower().lstrip("www.") == urlparse(b).netloc.lower().lstrip("www.")

def normalize(url):
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}{p.path or '/'}"

def fetch(url):
    try:
        start = time.perf_counter()
        r = requests.get(
            url,
            headers={"User-Agent": USER_AGENT},
            timeout=DEFAULT_TIMEOUT,
            allow_redirects=True
        )
        elapsed_ms = round((time.perf_counter() - start) * 1000)
        return r, elapsed_ms, None
    except requests.RequestException as e:
        return None, None, f"{type(e).__name__}: {e}"

def extract(url, html, load_ms):
    soup = BeautifulSoup(html, "html.parser")
    title = (soup.title.get_text(" ", strip=True) if soup.title else "")
    desc_tag = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
    description = desc_tag.get("content", "").strip() if desc_tag else ""

    images = soup.find_all("img")
    alt_present = sum(1 for img in images if img.get("alt", "").strip())
    forms = soup.find_all("form")

    links = []
    social = []
    ctas = []
    for a in soup.find_all("a", href=True):
        href = urljoin(url, a["href"])
        text = a.get_text(" ", strip=True)
        links.append(href)
        host = urlparse(href).netloc.lower()
        if any(h in host for h in SOCIAL_HOSTS):
            social.append(href)
        if any(term in text.lower() for term in CTA_TERMS):
            ctas.append(text[:100])

    nav = []
    for nav_tag in soup.find_all(["nav", "header"]):
        for a in nav_tag.find_all("a", href=True):
            t = a.get_text(" ", strip=True)
            if t:
                nav.append(t[:80])

    return {
        "url": url,
        "status_code": 200,
        "load_time_ms": load_ms,
        "title": title,
        "meta_description": description,
        "forms": len(forms),
        "contact_form_detected": any(
            any(k in (f.get_text(" ", strip=True) + " " + str(f)).lower()
                for k in ("contact", "message", "email", "phone"))
            for f in forms
        ),
        "cta_count": len(ctas),
        "cta_examples": ctas[:8],
        "social_links": sorted(set(social))[:12],
        "images": len(images),
        "images_with_alt": alt_present,
        "alt_coverage_pct": round((alt_present / len(images)) * 100, 1) if images else None,
        "nav_items": list(dict.fromkeys(nav))[:30],
        "internal_links": sorted(set(x for x in links if same_domain(url, x)))[:50],
    }

def crawl(start_url):
    start_url = normalize(start_url)
    q = deque([start_url])
    seen = set()
    pages = []
    errors = []

    while q and len(pages) < MAX_PAGES:
        url = q.popleft()
        if url in seen:
            continue
        seen.add(url)

        r, ms, err = fetch(url)
        if err:
            errors.append({"url": url, "error": err})
            continue
        if r.status_code >= 400:
            errors.append({"url": url, "error": f"HTTP {r.status_code}"})
            continue
        ctype = r.headers.get("content-type", "")
        if "text/html" not in ctype:
            continue

        fact = extract(r.url, r.text, ms)
        fact["final_url"] = r.url
        pages.append(fact)

        for link in fact["internal_links"]:
            clean = link.split("#")[0]
            if same_domain(start_url, clean) and clean not in seen:
                q.append(clean)

        time.sleep(DELAY_SECONDS)

    return {
        "site": start_url,
        "pages_scanned": len(pages),
        "pages": pages,
        "errors": errors,
        "crawler_limits": {
            "max_pages": MAX_PAGES,
            "delay_seconds": DELAY_SECONDS,
            "timeout_seconds": DEFAULT_TIMEOUT
        }
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("urls", nargs="+")
    ap.add_argument("--out", default="audit_facts.json")
    args = ap.parse_args()

    results = []
    for url in args.urls:
        print(f"Auditing {url}")
        results.append(crawl(url))

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print(f"Wrote {args.out}")

if __name__ == "__main__":
    main()
