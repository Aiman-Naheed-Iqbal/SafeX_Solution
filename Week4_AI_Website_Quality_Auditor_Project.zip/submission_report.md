# Week 4 Submission — AI-Assisted Website Quality Auditor
## Tax Advisory Sector

**Student deliverable:** Python + BeautifulSoup bounded website auditor, structured LLM scoring prompt, and portfolio-ready reporting design.

### 1. Problem
Tax advisory firms need websites that communicate services clearly, establish trust, make contact easy, and provide basic search/accessibility signals. This project turns those expectations into a small AI-assisted audit workflow.

### 2. Sites selected for the public, low-rate demonstration set
The sites below were selected as public, reading-oriented targets. They are not aggressively scanned, forms are not submitted, and the provided code caps requests.

| Site | Public starting page | Evidence snapshot |
|---|---|---|
| KPMG Pakistan Tax | https://kpmg.com/pk/en/services/tax-services.html | Tax services, service categories, team/contact signals and publications are publicly presented. |
| EY Pakistan Tax | https://www.ey.com/en_pk/services/tax | Tax disciplines and team information are publicly presented. |
| RSM Pakistan Tax | https://www.rsm.global/pakistan/service/tax-services | Tax service categories and a contact form are publicly visible. |
| Grant Thornton Pakistan | https://www.grantthornton.pk/ | Tax is presented as a core service; the site also exposes a contact page/form. |
| Forvis Mazars Pakistan | https://www.forvismazars.com/pk/en | Tax/advisory positioning, services, offices and contact options are publicly presented. |
| PwC US Tax | https://www.pwc.com/us/en/services/tax.html | Tax solutions and service areas are publicly presented. |
| Deloitte Global Tax | https://www.deloitte.com/global/en/services/tax.html | Business tax, indirect tax, international tax, transfer pricing and M&A tax are publicly presented. |

### 3. Architecture

```text
Public/authorized URL
        |
        v
Bounded requests + BeautifulSoup crawler
        |
        +--> automatic facts JSON
        |      - pages found
        |      - navigation
        |      - forms
        |      - CTAs
        |      - social links
        |      - title/description
        |      - alt coverage
        |      - request timing
        |      - errors
        |
        v
LLM scoring prompt
        |
        +--> score (0-100)
        +--> problems
        +--> missing features
        +--> prioritized recommendations
        +--> confidence / human checks
        |
        v
Human verification
        |
        v
Final report
```

### 4. Automatic facts vs AI judgment

**Automatically detected facts**
- HTTP status and request timing
- number of HTML pages discovered, subject to a 12-page cap
- navigation link labels
- forms and contact-form signals
- CTA-like link/button text
- social links
- meta title and description
- image alt-text coverage

**AI-generated judgment**
- 0–100 score
- why a detected issue matters
- missing-feature interpretation
- priority of recommendations
- confidence and human-review checklist

The LLM is explicitly instructed not to invent facts or turn "not detected" into "absent."

### 5. Tax-advisory website quality model

| Dimension | Weight |
|---|---:|
| Contact / lead capture | 20 |
| Navigation and service clarity | 15 |
| CTA / lead generation | 15 |
| SEO basics | 15 |
| Accessibility/content basics | 10 |
| Trust / business-readiness signals | 15 |
| Social / engagement links | 5 |
| Technical availability / load signal | 5 |
| **Total** | **100** |

The score is a heuristic portfolio metric, not an industry certification or objective measure of business quality.

### 6. Demonstration evidence
Public pages reviewed during preparation show that tax-advisory sites commonly expose service categories, contact routes, professionals/teams, and insight content. For example, KPMG Pakistan's tax page lists corporate tax, indirect tax, global mobility, M&A, trade/customs and transfer pricing, and identifies its tax team and locations. RSM Pakistan's tax page lists multiple tax services and exposes a contact form. Grant Thornton Pakistan exposes Tax as a service and has a dedicated contact form. Forvis Mazars Pakistan exposes contact options and a contact form, while PwC and Deloitte publish structured tax service areas.

These are **public-page observations**, not substitutes for the crawler's automatically detected JSON. The final score should be generated from an actual run of `auditor.py`, then checked against the live pages.

### 7. Failure handling
The crawler catches:
- DNS/connection errors
- request timeouts
- HTTP 4xx/5xx responses
- non-HTML resources

A failure is recorded in an `errors` array and does not terminate the entire multi-site audit.

### 8. LLM prompt design
The prompt forces:
1. JSON-only structured output.
2. Fact/judgment separation.
3. No invented evidence.
4. Concrete recommendations.
5. Priority labels: High / Medium / Low.
6. Human-check items.
7. A confidence field.
8. Explicit treatment of JavaScript and measurement limitations.

### 9. Sanity-check procedure
After an audit run:
1. Open each starting page manually.
2. Verify a sample of extracted facts.
3. Check every high-priority recommendation against the actual page.
4. Compare the score with a human review using the same dimensions.
5. Investigate large score differences instead of assuming the model is correct.
6. Re-run after fixes and check whether the score changes for the intended reason.

### 10. Limitations / false-positive risks
- A 12-page crawl is not a full site inventory.
- JavaScript-rendered content may be invisible to BeautifulSoup.
- A simple HTTP timer is not a Lighthouse/Core Web Vitals measurement.
- An absent signal in the crawl means "not detected."
- CTA keyword matching can create false positives.
- Contact-form detection is heuristic.
- Alt-text coverage does not equal full accessibility compliance.
- Social links can be loaded dynamically.
- Large professional-service websites can have localized or consent-gated content.
- The LLM can produce plausible but incorrect judgments; every recommendation must be verified by a human.

### 11. GitHub submission checklist
- [x] Bounded, low-rate crawler
- [x] Fact vs AI judgment separation
- [x] Structured scoring prompt
- [x] Failure handling
- [x] README and limitations
- [x] Public demonstration site list
- [ ] Run final crawl locally and commit the resulting `audit_facts.json`
- [ ] Verify final AI scores against live pages
- [ ] Push repository to GitHub

### 12. Conclusion
This project demonstrates a realistic AI-product pattern: deterministic extraction first, LLM interpretation second, and human verification last. The separation reduces hallucination risk and makes the report auditable.
